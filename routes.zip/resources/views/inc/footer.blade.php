<!-- Footer -->
<footer class="content-footer footer bg-footer-theme">
  <div class="container-xxl d-flex flex-wrap justify-content-between py-2">
    <div class="mb-2 mb-md-0 text-center">
     <span class="text-muted"> &copy; {{ date("Y") }} - {{ config('app.name') }} - Powered by Noorsoft</span>
    </div>
  </div>
</footer>
<!-- / Footer -->

<div class="content-backdrop fade"></div>